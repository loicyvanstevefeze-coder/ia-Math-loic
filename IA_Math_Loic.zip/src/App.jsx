import { useState } from "react";

export default function IAMathLoic() {
  const [messages, setMessages] = useState([
    { role: "ai", text: "👋 Bienvenue sur IA Math Loïc 🤖📚\nJe suis ton assistant de mathématiques L1/L2/L3." }
  ]);
  const [input, setInput] = useState("");

  const knowledge = {
    analyse: "📘 Analyse : fonctions, limites, dérivées, intégrales et séries.",
    algebre: "📘 Algèbre : espaces vectoriels, matrices, applications linéaires.",
    probabilite: "📘 Probabilités : variables aléatoires, lois de probabilité, espérance.",
    derivee: "📗 Dérivée : variation d'une fonction. Exemple : (x²)' = 2x.",
    integrale: "📗 Intégrale : calcul des aires.",
    matrice: "📗 Matrice : tableau de transformation linéaire.",
    limite: "📗 Limite : comportement d'une fonction."
  };

  const sendMessage = () => {
    if (!input.trim()) return;

    const userMsg = { role: "user", text: input };

    let response = "🤖 IA Math Loïc : notion non trouvée.";

    const lower = input.toLowerCase();
    for (let key in knowledge) {
      if (lower.includes(key)) {
        response = knowledge[key];
        break;
      }
    }

    const aiMsg = { role: "ai", text: response };

    setMessages([...messages, userMsg, aiMsg]);
    setInput("");
  };

  return (
    <div style={{minHeight:"100vh",background:"#111",color:"#fff",display:"flex",flexDirection:"column"}}>
      <header style={{padding:"10px",textAlign:"center",borderBottom:"1px solid #333"}}>
        IA Math Loïc 🤖📚
      </header>

      <div style={{flex:1,padding:10,overflowY:"auto"}}>
        {messages.map((m,i)=>(
          <div key={i} style={{
            margin:"5px",
            padding:"10px",
            background:m.role==="user"?"#2563eb":"#333",
            borderRadius:"10px",
            maxWidth:"70%",
            marginLeft:m.role==="user"?"auto":"0"
          }}>
            {m.text}
          </div>
        ))}
      </div>

      <div style={{display:"flex",padding:10,borderTop:"1px solid #333"}}>
        <input 
          value={input}
          onChange={(e)=>setInput(e.target.value)}
          style={{flex:1,padding:10}}
          placeholder="Pose ta question..."
        />
        <button onClick={sendMessage} style={{padding:10}}>
          Envoyer
        </button>
      </div>
    </div>
  );
}
